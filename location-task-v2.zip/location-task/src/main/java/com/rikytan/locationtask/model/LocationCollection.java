package com.rikytan.locationtask.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

public class LocationCollection {

	private static LocationCollection instance = null;
	private List<Location> locations = null;
	
	private LocationCollection() {
		
	}
	
	public static LocationCollection getInstance() {
		if (instance==null) {
			instance = new LocationCollection();
		}
		return instance;
	}
	public List<Location> getList() {
		if (locations == null) {
			readLocationFromFile();
		}
		return  Collections.unmodifiableList(locations);		
	}

	private void readLocationFromFile() {
		locations =  new ArrayList<Location>();
		File file = new File("locations.csv");
		if (!file.exists()) {
			JOptionPane.showMessageDialog(null, "locations.csv" + " file does not exist", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		FileReader fIn;
		try {
			fIn = new FileReader(file);
			BufferedReader bIn = new BufferedReader(fIn);
			String line;
			line = bIn.readLine(); //skip header
			line = bIn.readLine();
			StringTokenizer token;
			double latitude;
			double longitude;
			String title;
			String address;
			while (line != null) {
				token = new StringTokenizer(line,",");
				latitude = Double.parseDouble(token.nextToken().trim());
				longitude = Double.parseDouble(token.nextToken().trim());
				title = token.nextToken().trim();
				address = token.nextToken().trim();
				Location location = new Location(latitude, longitude, title, address);
				locations.add(location);
				line = bIn.readLine();
			}
			bIn.close();
			fIn.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<Location> getSortedList() {
		List<Location> data = new ArrayList(getList());
		for (int i = 0; i < data.size(); i++) {
			for (int j = data.size() - 1; j > i; j--) {
				if (data.get(i).getTitle().compareToIgnoreCase(data.get(j).getTitle())>0) {
					Location tmp = data.get(i);
					data.set(i,data.get(j)) ;
					data.set(j,tmp);

				}

			}

		}
		return data;
	}
}
