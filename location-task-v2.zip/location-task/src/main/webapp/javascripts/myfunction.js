$(function (){
	var $displayresult = $('#displayresult');
	var $url = $('#url');
	var tableToObj = function( table ) {
    		var trs = table.rows,
        		trl = trs.length,
        		i = 0,
        		j = 0,
        		keys = [],
        		obj, ret = [];

    		for (; i < trl; i++) {
        	if (i == 0) {
            	for (; j < trs[i].children.length; j++) {
                	keys.push(trs[i].children[j].innerHTML);
            	}
        	} else {
            	obj = {};
            	for (j = 0; j < trs[i].children.length; j++) {
                	obj[keys[j]] = trs[i].children[j].innerHTML;
            	}
            	ret.push(obj);
        	}
    	}
    	return ret;
	};
		
	$('#post-button').on('click', function(event) {
		var obj = tableToObj(document.getElementById('report'));
		$.ajax({
			contentType: 'application/json',
			type: 'POST',
			url: $url.val(),
			data: obj,
			dataType: 'json',
			success: function(result,status,xhr) {
				$displayresult.empty();
				$displayresult.append('<h2>Success Sending Post. Status Code: ' + xhr.status + '</h2>');
			},
			error: function(xhr,status,error) {
				$displayresult.empty();
				$displayresult.append('<h2>Error Sending Post. Status Code: ' + xhr.status + '</h2>');
			}
		});
		return false;
	});	
	
	$('#get-button').click(function(){
	   $.ajax({
			contentType: 'application/json',
			type: 'GET',
			url: $url.val(),
			data: {},
			dataType: 'json',
			success: function(result,status,xhr) {
				var jsondata = JSON.stringify(result);
				$displayresult.empty();
				$displayresult.append('<h2>Success Sending Get Request. <br/>Data:</h2>' + jsondata);
			},
			error: function(xhr,status,error) {
				$displayresult.empty();
				$displayresult.append('<h2>Error Sending Get Request. Status Code: ' + xhr.status + '</h2>');
			}
		});
		return false;
	});
		
});
