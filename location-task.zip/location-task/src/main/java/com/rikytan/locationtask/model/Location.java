package com.rikytan.locationtask.model;

public class Location {
	private double latitude;
	private double longitude;
	private String title;
	private String address;
	
	public Location() {
		
	}

	public Location(double latitude, double longitude, String title, String address) {
		super();
		this.latitude = latitude;
		this.longitude = longitude;
		this.title = title;
		this.address = address;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
		
}
