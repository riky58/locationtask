package com.rikytan.locationtask.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.rikytan.locationtask.model.Location;
import com.rikytan.locationtask.model.LocationCollection;  

@Controller  
public class LocationController {  
	 
    
    public LocationController() {
	}

	
    /* It provides list of employees in model object */  
    @RequestMapping("/")  
    public ModelAndView viewemp(){  
        List<Location> list=(List<Location>) LocationCollection.getInstance().getSortedList();  
        return new ModelAndView("index","list",list);  
    }    
  
}  
