$(function (){
	var $url = $('#url');
	var formData = JSON.stringify($("#myForm").serializeArray());
		
	$('#post-button').on('click', function() {
		$.ajax({
			contentType: 'application/json',
			type: 'POST',
			url: $url.val(),
			data: formData,
			dataType: 'json',
			success: function() {
				alert('success');
			},
			error: function() {
				alert('error');
			}
		});
	});	
	
	$('#get-button').click(function(){
	    $.get($url.val(),
	    {	        
	    },
	    function(data, status){
	        alert('Data: ' + data + '\nStatus: ' + status);
	    });
	});
	
});
